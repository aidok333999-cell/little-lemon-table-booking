import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import BookingForm from "./BookingForm";

const times = ["17:00", "18:00"];

function renderForm(overrides = {}) {
  return render(
    <BookingForm
      availableTimes={times}
      dispatch={vi.fn()}
      submitForm={vi.fn()}
      {...overrides}
    />
  );
}

describe("BookingForm", () => {
  it("renders accessible controls with labels and constraints", () => {
    renderForm();

    expect(screen.getByRole("form", { name: /table booking form/i })).toBeInTheDocument();
    expect(screen.getByLabelText(/choose date/i)).toHaveAttribute("type", "date");
    expect(screen.getByLabelText(/number of guests/i)).toHaveAttribute("min", "1");
    expect(screen.getByLabelText(/number of guests/i)).toHaveAttribute("max", "10");
    expect(screen.getByRole("combobox", { name: /choose time/i })).toHaveValue("");
    expect(screen.getByRole("button", { name: /make your reservation/i })).toBeInTheDocument();
  });

  it("dispatches the selected date and resets the time", () => {
    const dispatch = vi.fn();
    renderForm({ dispatch });

    fireEvent.change(screen.getByLabelText(/choose date/i), {
      target: { value: "2026-08-25" },
    });

    expect(dispatch).toHaveBeenCalledWith("2026-08-25");
    expect(screen.getByRole("combobox", { name: /choose time/i })).toHaveValue("");
  });

  it("shows meaningful errors for an incomplete form", () => {
    renderForm();

    fireEvent.click(screen.getByRole("button", { name: /make your reservation/i }));

    expect(screen.getByText(/choose a reservation date/i)).toHaveAttribute("role", "alert");
    expect(screen.getByText(/choose an available time/i)).toHaveAttribute("role", "alert");
    expect(screen.getByLabelText(/choose date/i)).toHaveAttribute("aria-invalid", "true");
  });

  it("submits valid form data", () => {
    const submitForm = vi.fn();
    renderForm({ submitForm });

    fireEvent.change(screen.getByLabelText(/choose date/i), {
      target: { value: "2027-01-10" },
    });
    fireEvent.change(screen.getByLabelText(/choose time/i), {
      target: { value: "17:00" },
    });
    fireEvent.change(screen.getByLabelText(/number of guests/i), {
      target: { value: "4" },
    });

    fireEvent.click(screen.getByRole("button", { name: /make your reservation/i }));

    expect(submitForm).toHaveBeenCalledWith({
      date: "2027-01-10",
      time: "17:00",
      guests: "4",
      occasion: "None",
    });
  });

  it("rejects an invalid party size", () => {
    const submitForm = vi.fn();
    renderForm({ submitForm });

    fireEvent.change(screen.getByLabelText(/choose date/i), {
      target: { value: "2027-01-10" },
    });
    fireEvent.change(screen.getByLabelText(/choose time/i), {
      target: { value: "17:00" },
    });
    fireEvent.change(screen.getByLabelText(/number of guests/i), {
      target: { value: "11" },
    });

    fireEvent.click(screen.getByRole("button", { name: /make your reservation/i }));

    expect(screen.getByText(/between 1 and 10 guests/i)).toBeInTheDocument();
    expect(submitForm).not.toHaveBeenCalled();
  });
});
