import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import App, { initializeTimes, updateTimes } from "./App";

describe("App booking flow", () => {
  it("initializeTimes returns available times for today", () => {
    expect(initializeTimes()).toEqual(expect.arrayContaining(["17:00"]));
  });

  it("updateTimes returns available times for the selected date", () => {
    expect(updateTimes([], "2026-08-24")).toEqual(expect.arrayContaining(["17:00"]));
  });

  it("renders the booking form and updates available times when the date changes", () => {
    render(<App />);

    expect(screen.getByRole("form", { name: /table booking form/i })).toBeInTheDocument();

    fireEvent.change(screen.getByLabelText(/choose date/i), {
      target: { value: "2026-08-24" },
    });

    expect(screen.getByRole("option", { name: "18:00" })).toBeInTheDocument();
  });

  it("shows a confirmation after a valid reservation", () => {
    render(<App />);

    fireEvent.change(screen.getByLabelText(/choose date/i), {
      target: { value: "2027-01-10" },
    });
    fireEvent.change(screen.getByLabelText(/choose time/i), {
      target: { value: "17:00" },
    });
    fireEvent.click(screen.getByRole("button", { name: /make your reservation/i }));

    expect(screen.getByRole("heading", { name: /booking confirmed/i })).toBeInTheDocument();
  });
});
