# Little Lemon Table Booking — Front-End Capstone

A responsive and accessible React table-reservation app for the Meta Front-End Developer Capstone. The project follows the Little Lemon visual language and is structured to address every item in the peer-review rubric.

## Features

- Responsive desktop and mobile layout based on the Little Lemon Figma design
- Semantic `header`, `nav`, `main`, `section`, `aside`, `form`, and `footer` elements
- Accessible labels, native controls, focus states, ARIA error descriptions and live confirmation
- `BookingForm` implemented as a child of the parent `App` component
- Available-time state managed in `App` with `useReducer`
- Date-dependent availability, client-side validation and field-level error messages
- Confirmation screen after successful submission
- Meta description, mobile viewport, theme color and Open Graph tags
- Unit tests for the form, validation, available times, date changes, confirmation flow and edge cases

## Run locally

```bash
git clone https://github.com/aidok333999-cell/little-lemon-table-booking.git
cd little-lemon-table-booking
npm install
npm run dev
```

Open the local URL printed by Vite (usually `http://localhost:5173`).

## Test and build

```bash
npm test
npm run build
```

## Project structure

```text
src/
├── components/
│   ├── BookingForm.jsx
│   ├── BookingForm.test.jsx
│   └── ConfirmedBooking.jsx
├── utils/
│   ├── bookingApi.js
│   └── bookingApi.test.js
├── App.jsx
├── main.jsx
└── styles.css
```

## Rubric notes

`BookingForm` receives `availableTimes`, `dispatch`, and `submitForm` from `App`. When the date changes, the child dispatches the selected date; the parent reducer calculates and stores the new available-time state. Invalid submissions remain on the form and show specific, screen-reader-accessible messages.

## Rubric checklist

- UI/UX: responsive Little Lemon-style hero, navigation, reservation section and confirmation state.
- Semantic HTML: `header`, `nav`, `main`, `section`, `aside`, `form`, `label`, `footer` and `address` are used appropriately.
- Responsive layout: desktop, tablet and mobile breakpoints are included in `styles.css`.
- SEO/social metadata: description, viewport, theme color and Open Graph title, description, URL, image and image alt are in `index.html`.
- Component structure: `BookingForm` is rendered by `App` and receives its data and callbacks as props.
- State management: `availableTimes` is managed by `App` with `useReducer`; `BookingForm` dispatches date changes to the parent.
- Client-side validation: date, available time and guest count are validated before submission, with accessible field-level messages.
- Unit tests: form rendering, accessibility, date dispatch, validation, submission, parent reducer helpers and confirmation are tested.
- Test command: `npm test`.
